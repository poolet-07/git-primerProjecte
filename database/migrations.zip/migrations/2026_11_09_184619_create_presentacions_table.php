<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('presentacions', function (Blueprint $table) {
            $table->id('pre_id');

            $table->string('ponent', 50);
            $table->date('data');
            $table->string('ciutat', 50);
            $table->string('acta', 50);
            $table->string('ordre', 50);



            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('presentacions');
    }
};
