<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('fotos_pre', function (Blueprint $table) {
            $table->id('foto_id');

            $table->unsignedBigInteger('pre_id');
            $table->foreign('pre_id')->references('pre_id')->on('presentacions')->onDelete('cascade');

            $table->string('ruta');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('fotos_pre');
    }
};
